﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public struct GrabbableData  {

    public string Name;
    public Sprite Sprite;
}
